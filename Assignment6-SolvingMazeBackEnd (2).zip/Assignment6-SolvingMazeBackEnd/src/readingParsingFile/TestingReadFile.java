package readingParsingFile;


public class TestingReadFile {

	public static void main(String[] args) {
		ReadFile testrun = new ReadFile();
		
		testrun.Read();
	}

}
